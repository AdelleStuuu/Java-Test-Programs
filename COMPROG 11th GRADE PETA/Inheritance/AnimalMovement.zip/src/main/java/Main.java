public class Main {
  public static void main(String[] args) {
    Animal animal = new Animal();
    animal.move();

    Cheetah cheetah = new Cheetah();
    cheetah.move();
  }
}