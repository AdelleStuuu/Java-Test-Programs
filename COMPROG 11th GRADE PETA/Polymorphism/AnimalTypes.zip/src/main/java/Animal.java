public class Animal {
  void eat() {
    System.out.println("- Animal eats");
  }

  void sound() {
    System.out.println("- Animal sounds");
  }
}