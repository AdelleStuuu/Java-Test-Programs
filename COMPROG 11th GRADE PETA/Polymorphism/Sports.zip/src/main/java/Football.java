public class Football {
  void play() {
    System.out.println("Kicking the ball" + " and scoring a goal");
  }
}