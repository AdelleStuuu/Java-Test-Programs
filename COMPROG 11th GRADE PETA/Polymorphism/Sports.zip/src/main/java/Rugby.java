public class Rugby {
  void play() {
    System.out.println("Carrying ball" + " and scoring a try");
  }
}