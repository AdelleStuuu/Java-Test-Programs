public class Car {
  void startEngine () {
    System.out.println("Gearbox neutral. Break Pedal Stomped. Engine started.");
  }
  void stopEngine () {
    System.out.println("Key removed from ignition. Engine stopped.");
  }
}