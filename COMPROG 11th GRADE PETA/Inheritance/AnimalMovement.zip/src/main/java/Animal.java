public class Animal {
  void move() {
    System.out.println("This animal is moving");
  }
}