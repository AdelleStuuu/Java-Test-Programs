public class Vehicle {
  void startEngine () {
    System.out.println("Engine started.");
  }
  void stopEngine () {
    System.out.println("Engine stopped.");
  }
}