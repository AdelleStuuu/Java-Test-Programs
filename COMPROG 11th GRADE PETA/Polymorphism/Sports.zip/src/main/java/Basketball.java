public class Basketball {
  void play() {
    System.out.println( "bouncing the ball" + " and scored the hoop" );
  }
}