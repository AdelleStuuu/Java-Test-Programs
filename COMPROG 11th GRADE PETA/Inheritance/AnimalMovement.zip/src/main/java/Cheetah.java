public class Cheetah extends Animal {
  void move() {
    System.out.println("This cheetah is running");
  }
}