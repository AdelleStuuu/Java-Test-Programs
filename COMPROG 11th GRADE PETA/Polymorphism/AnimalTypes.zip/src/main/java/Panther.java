public class Panther {
  void eat() {
    System.out.println("- Panther eats Hog");
  }

  void sound() {
    System.out.println("- Panther meows");
  }
}