public class Tiger {
  void eat() {
    System.out.println("- Tiger eats deer");
  }

  void sound() {
    System.out.println("- Tiger roars");
  }
}