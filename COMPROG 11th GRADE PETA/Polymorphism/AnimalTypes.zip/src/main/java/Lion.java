public class Lion {
  void eat() {
    System.out.println("- Lion eats Cow");
  }

  void sound() {
    System.out.println("- Lion Roars loudly");
  }
}