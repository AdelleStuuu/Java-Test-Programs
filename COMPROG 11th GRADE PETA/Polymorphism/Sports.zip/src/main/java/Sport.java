public class Sport {
  void play() {
    System.out.println("Playing sport");
  }
}