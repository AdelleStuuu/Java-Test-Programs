public class Motorcycle {
  void startEngine () {
    System.out.println("Clutch held. Engine start button pressed. Engine started.");
  }
  void stopEngine () {
    System.out.println("Kickstand dropped. Engine stopped.");
  }
}